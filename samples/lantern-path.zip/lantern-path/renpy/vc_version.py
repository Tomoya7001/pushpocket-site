# Lantern Path marker (written for PushPocket, not Ren'Py code). A Ren'Py SDK build puts the engine in renpy/;
# PushPocket runs games with its own bundled Ren'Py 8 runtime, so this sample ships only this file, which tells
# the detector (tools/detector: renpy/ directory + renpy/vc_version.py) which Ren'Py line the script targets.
# The runtime never imports this file.
version = '8.5.3.25000000'
