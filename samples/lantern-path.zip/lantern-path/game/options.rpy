# Lantern Path options (written for PushPocket).
define config.name = "Lantern Path"
define config.version = "1.0"
define config.save_directory = "lantern-path-pushpocket"
define config.has_autosave = False
define config.autosave_on_quit = False
