# Lantern Path: PushPocket's reviewer sample game. Written for PushPocket; every visual is drawn in code
# (solid colors and Ren'Py's own text), there are no image, sound or font files. About 1-3 minutes of play.
# The text is English because the font Ren'Py ships with (DejaVuSans, part of the bundled runtime) has no
# Japanese glyphs, and this sample adds no font of its own.

init python:
    def Box(color, w, h):
        return Transform(Solid(color), xysize=(w, h))

    def Lantern(lamp):
        return Fixed(
            Transform(Box("#4a4f5a", 14, 120), xalign=0.5, yalign=1.0),
            Transform(Box("#2f333b", 70, 10), xalign=0.5, ypos=54),
            Transform(Box(lamp, 56, 54), xalign=0.5, yalign=0.0),
            xysize=(70, 174),
        )

    AMBER = "#ffcf70"
    BLUE = "#7cc4ff"
    GREEN = "#8be08b"
    DARK = "#3a414c"

# Readable text and large choice buttons for touch (the game has no gui.rpy / screens.rpy of its own).
style say_dialogue:
    size 28

screen choice(items):
    vbox:
        xalign 0.5
        yalign 0.42
        spacing 16
        for i in items:
            textbutton i.caption:
                action i.action
                xminimum 460
                xalign 0.5
                xpadding 28
                ypadding 16
                background Solid("#2f3a52")
                hover_background Solid("#4a5d85")
                text_size 30
                text_color "#ffffff"
                text_hover_color "#ffffff"
                text_xalign 0.5

# The first scene's background. ios/HostAppUITests/ReviewerSampleUITests.swift checks this color on screen.
image bg night = Solid("#1d2433")
image bg dawn = Solid("#3d4f6e")
image ground = Box("#27352b", 800, 140)
image gate shut = Box("#5b4a3a", 150, 230)
image gate open = Box("#c9b48a", 150, 230)

image lantern1 off = Lantern(DARK)
image lantern1 on = Lantern(AMBER)
image lantern2 off = Lantern(DARK)
image lantern2 on = Lantern(BLUE)
image lantern3 off = Lantern(DARK)
image lantern3 on = Lantern(GREEN)

transform post(x):
    anchor (0.5, 1.0)
    xpos x
    ypos 0.86

transform glow:
    alpha 1.0
    linear 0.9 alpha 0.7
    linear 0.9 alpha 1.0
    repeat

default lit = 0
default wind_tries = 0
default dial_tries = 0

label start:
    $ lit = 0
    $ wind_tries = 0
    $ dial_tries = 0
    scene bg night
    show ground:
        anchor (0.5, 1.0)
        xpos 0.5
        ypos 1.0
    "Welcome to Lantern Path, a short sample game made for PushPocket."
    "Tap anywhere to read on. When choices appear, tap one."
    show lantern1 off at post(0.2)
    show lantern2 off at post(0.45)
    show lantern3 off at post(0.7)
    show gate shut:
        anchor (0.5, 1.0)
        xpos 0.9
        ypos 0.86
    "Three dark lanterns stand along the path to the gate. Light all three, and the gate will open."
    jump lantern_one

label lantern_one:
    menu:
        "The first lantern is cold. There is a box of matches at its foot."
        "Strike a match":
            show lantern1 on at post(0.2), glow
            $ lit += 1
            "The match flares, and the lantern glows amber."
        "Walk past it":
            "It is too dark to see the path. You turn back to the lantern."
            jump lantern_one
    jump lantern_two

label lantern_two:
    menu:
        "The second lantern has a dial with three shapes. A note on it reads: \"I have no corners.\""
        "Circle":
            show lantern2 on at post(0.45), glow
            $ lit += 1
            "Click. The lantern lights up blue."
        "Square":
            $ dial_tries += 1
            "Nothing happens. A square has four corners."
            jump lantern_two
        "Triangle":
            $ dial_tries += 1
            "Nothing happens. A triangle has three corners."
            jump lantern_two
    jump lantern_three

label lantern_three:
    menu:
        "The third lantern catches a flame, but the wind is rising."
        "Shield the flame with your hands":
            show lantern3 on at post(0.7), glow
            $ lit += 1
            "The flame steadies. The lantern glows green."
        "Hurry on to the gate":
            $ wind_tries += 1
            "The wind blows the flame out. Better try again."
            jump lantern_three
    jump gate

label gate:
    "All three lanterns are lit. A voice from the gate asks a question."
    jump gate_question

label gate_question:
    menu:
        "\"What color did the first lantern glow?\""
        "Amber":
            jump gate_open
        "Blue":
            "\"No. That was the second one.\""
            jump gate_question
        "Green":
            "\"No. That was the third one.\""
            jump gate_question

label gate_open:
    scene bg dawn
    show ground:
        anchor (0.5, 1.0)
        xpos 0.5
        ypos 1.0
    show lantern1 on at post(0.2)
    show lantern2 on at post(0.45)
    show lantern3 on at post(0.7)
    show gate open:
        anchor (0.5, 1.0)
        xpos 0.9
        ypos 0.86
    "The gate swings open, and the sky begins to brighten."
    $ mistakes = dial_tries + wind_tries
    if mistakes == 0:
        "You reached the gate without a single misstep."
    else:
        "You reached the gate after [mistakes] wrong turn(s)."
    show expression Text("The End", size=64, color="#ffffff") as the_end:
        xalign 0.5
        ypos 0.12
    menu:
        "Thank you for playing Lantern Path."
        "Play again":
            hide the_end
            jump start
        "Finish":
            return
    return
