# Lantern Path（ランタンの小道）— App Review 用サンプルゲーム

PushPocket の審査担当者が「ゲームを取り込み、プレイする」流れを試すための、私たちが作った短い Ren'Py 8 のゲームです。
遊ぶ時間は 1〜3 分。ランタンを 3 つ灯して門を開けます（選択肢 4 か所、間違えると同じ場所に戻ってやり直し、最後に「もう一度」か「終了」）。

## 中身と権利

| ファイル | 内容 | 権利 |
|---|---|---|
| game/script.rpy | ゲームのスクリプト。絵はすべて単色の四角（`Solid`）と文字（`Text`）をコードで描く | PushPocket の自作 |
| game/options.rpy | ゲーム名・版・保存フォルダ名 | PushPocket の自作 |
| renpy/vc_version.py | 判定用の目印（Ren'Py の版 8.5.3 を書いた 1 行）。Ren'Py のコードではない | PushPocket の自作 |

- 画像・音・フォントのファイルはありません。第三者の素材はゼロです。
- 文字は、アプリに同梱している Ren'Py 8 実行環境の標準フォント（DejaVuSans、実行環境の一部としてライセンス一覧に載っているもの）で表示します。
  このフォントには日本語の字形がないため、ゲーム内の文は英語です。
- Ren'Py のエンジン本体は入れていません。PushPocket はアプリに内蔵した Ren'Py 8 実行環境でゲームを動かすためです。
- DRM・ストアの検査・エミュレーションはありません。

## パッケージの作り方（ユーザーが取り込む形）

リポジトリの一番上で、次を順に実行します。出力は build/reviewer-sample/ に入り、コミットしません（build/ は .gitignore 済み）。

```
rm -rf build/reviewer-sample
mkdir -p "build/reviewer-sample/ランタンの小道 Lantern Path"
cp -R samples/lantern-path/game samples/lantern-path/renpy "build/reviewer-sample/ランタンの小道 Lantern Path/"
(cd build/reviewer-sample && python3 -m zipfile -c "ランタンの小道 Lantern Path.zip" "ランタンの小道 Lantern Path")
```

zip は python3 の標準の zipfile で作ります。日本語の名前に UTF-8 の印（汎用フラグ 0x800）が付くためです。
macOS の `zip` と `ditto` はこの印を付けず、展開する道具によっては名前が文字化けします（PushPocket 自体はどちらでも読めます）。

できるもの：

- build/reviewer-sample/ランタンの小道 Lantern Path/（フォルダ。「PC から転送」や「ファイル」アプリからのフォルダ取り込み用）
- build/reviewer-sample/ランタンの小道 Lantern Path.zip（zip。審査担当者に渡す形）

ライブラリのカードの名前は、フォルダ名（zip なら .zip を除いた名前）になります。

## 確認のしかた

判定（アプリと同じ検出器）：

```
cargo run -q --release --manifest-path tools/detector/Cargo.toml --bin detector -- "build/reviewer-sample/ランタンの小道 Lantern Path"
```

`"engine":"renpy"`、`"engineVersion":"8.5.3.25000000"`、`"route":"pillarA:renpy"`、`"drm":"none"` が出れば、アプリでは「動作見込み」になります
（ios/HostApp/Library/Store/GameDetection.swift の `Compatibility.assess`）。

シミュレータ（iPad と iPhone、消音）での取り込みとプレイ：ios/HostAppUITests/ReviewerSampleUITests.swift。
このフォルダを日本語名で 2 回取り込み（2 回目は上書き更新でカード 1 枚）、「動作見込み」、「プレイ」、最初の文と最初の画面の色、
タップで文を進め選択肢を選んで最後（The End）まで遊べることを確かめます。
正解はどの選択肢でも一番上のボタンです（テストはその位置を計算して押す）。選択肢の並びやボタンの大きさを変えたら、
テストの `firstButtonY` も合わせてください。
